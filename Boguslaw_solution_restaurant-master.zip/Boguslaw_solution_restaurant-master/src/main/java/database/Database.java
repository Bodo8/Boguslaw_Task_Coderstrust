package database;

import model.Order;

import java.util.List;

public interface Database {

  void saveOrder(Order order);

  void removeOrder(Order order);

  List<Order> getOrder(Integer year, String month, Integer day);

  List<Order> getAllOrders();
}
