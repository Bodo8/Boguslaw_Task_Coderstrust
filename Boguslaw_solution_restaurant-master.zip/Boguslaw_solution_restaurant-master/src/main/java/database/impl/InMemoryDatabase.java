package database.impl;

import database.Database;
import model.Order;

import java.util.ArrayList;
import java.util.List;

public class InMemoryDatabase implements Database {

  private final List<Order> orders = new ArrayList<>();

  @Override
  public void saveOrder(Order order) {
    orders.add(order);
  }

  @Override
  public List<Order> getOrder(Integer year, String month, Integer day) {
    return orders;
  }

  @Override
  public List<Order> getAllOrders() {
    return orders;
  }

  @Override
  public void removeOrder(Order order) {
    orders.remove(order);
  }


}
