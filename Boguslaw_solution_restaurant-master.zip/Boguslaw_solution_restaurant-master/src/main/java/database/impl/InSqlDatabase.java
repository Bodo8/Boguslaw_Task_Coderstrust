package database.impl;

import database.Database;
import model.Order;

import java.util.ArrayList;
import java.util.List;

/**
 * the class save orders in the SQL database. Class not yet implemented.
 */
public class InSqlDatabase implements Database {


  @Override
  public void saveOrder(Order order) {

  }

  @Override
  public List<Order> getOrder(Integer year, String month, Integer day) {
    List<Order> orders = new ArrayList<>();
    return orders;
  }

  @Override
  public List<Order> getAllOrders() {
    return null;
  }

  @Override
  public void removeOrder(Order order) {

  }
}
