package model;

import model.drinks.Drink;
import model.menu.ItalianMenuLunch;
import model.menu.MenuDesert;
import model.menu.MexicanMenuLunch;
import model.menu.PolishMenuLunch;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Create instance of Order class.
 */
public class Order {

  private LocalDate date = LocalDate.now();
  private ItalianMenuLunch italianDish;
  private MexicanMenuLunch mexicanDish;
  private PolishMenuLunch polishDish;
  private Drink drink;
  private MenuDesert desert;
  private BigDecimal price;

  public Order() {
  }

  /**
   * constructor needed for builder.
   *
   * @param date date order.
   * @param italianDish Italian menu.
   * @param mexicanDish Mexican menu.
   * @param polishDish Polish menu.
   * @param drink drink menu.
   * @param desert desert menu.
   * @param price price.
   */
  public Order(LocalDate date, ItalianMenuLunch italianDish, MexicanMenuLunch mexicanDish,
      PolishMenuLunch polishDish, Drink drink, MenuDesert desert,
      BigDecimal price) {
    this.date = date;
    this.italianDish = italianDish;
    this.mexicanDish = mexicanDish;
    this.polishDish = polishDish;
    this.drink = drink;
    this.desert = desert;
    this.price = price;
  }

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public ItalianMenuLunch getItalianDish() {
    return italianDish;
  }

  public void setItalianDish(ItalianMenuLunch italianDish) {
    this.italianDish = italianDish;
  }

  public MexicanMenuLunch getMexicanDish() {
    return mexicanDish;
  }

  public void setMexicanDish(MexicanMenuLunch mexicanDish) {
    this.mexicanDish = mexicanDish;
  }

  public PolishMenuLunch getPolishDish() {
    return polishDish;
  }

  public void setPolishDish(PolishMenuLunch polishDish) {
    this.polishDish = polishDish;
  }

  public Drink getDrink() {
    return drink;
  }

  public void setDrink(Drink drink) {
    this.drink = drink;
  }

  public MenuDesert getDesert() {
    return desert;
  }

  public void setDesert(MenuDesert desert) {
    this.desert = desert;
  }

  public BigDecimal getPrice() {
    return price;
  }

  public void setPrice(BigDecimal price) {
    this.price = price;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
      return false;
    }

    Order order = (Order) obj;

    if (date != null ? !date.equals(order.date) : order.date != null) {
      return false;
    }
    if (italianDish != null ? !italianDish.equals(order.italianDish) : order.italianDish != null) {
      return false;
    }
    if (mexicanDish != null ? !mexicanDish.equals(order.mexicanDish) : order.mexicanDish != null) {
      return false;
    }
    if (polishDish != order.polishDish) {
      return false;
    }
    if (drink != null ? !drink.equals(order.drink) : order.drink != null) {
      return false;
    }
    if (desert != null ? !desert.equals(order.desert) : order.desert != null) {
      return false;
    }
    return price != null ? price.equals(order.price) : order.price == null;
  }

  @Override
  public int hashCode() {
    int result = date != null ? date.hashCode() : 0;
    result = 31 * result + (italianDish != null ? italianDish.hashCode() : 0);
    result = 31 * result + (mexicanDish != null ? mexicanDish.hashCode() : 0);
    result = 31 * result + (polishDish != null ? polishDish.hashCode() : 0);
    result = 31 * result + (drink != null ? drink.hashCode() : 0);
    result = 31 * result + (desert != null ? desert.hashCode() : 0);
    result = 31 * result + (price != null ? price.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "Order{"
        + "date=" + date
        + ", italianDish=" + italianDish
        + ", mexicanDish=" + mexicanDish
        + ", polishDish=" + polishDish
        + ", drink=" + drink
        + ", desert=" + desert
        + ", price=" + price
        + '}';
  }
}
