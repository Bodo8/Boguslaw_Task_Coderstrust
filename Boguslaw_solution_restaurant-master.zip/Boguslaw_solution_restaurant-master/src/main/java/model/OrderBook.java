package model;

import database.Database;

import java.util.List;

/**
 * Order Book.
 */
public class OrderBook {

  private final Database database;

  public OrderBook(Database database) {
    this.database = database;
  }

  /**
   * add order to the database.
   * @param order object order class.
   */
  public void addOrder(Order order) {
    database.saveOrder(order);
  }

  public void removeOrder(Order order) {
    database.removeOrder(order);
  }

  /**
   * @param year tells from which year order should be provided.
   * @param month tells from which month order should be provided.
   * @param day tells from which day order should be provided.
   */
  public List<Order> getOrderOfDay(Integer year, String month, Integer day) {
    return database.getOrder(year, month, day);
  }

  /**
   * get orders from database.
   *
   * @return objects order class.
   */
  public List<Order> getOrders() {
    return database.getAllOrders();
  }

}
