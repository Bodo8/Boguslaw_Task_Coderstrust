package model;

import model.drinks.Drink;
import model.menu.ItalianMenuLunch;
import model.menu.MenuDesert;
import model.menu.MexicanMenuLunch;
import model.menu.PolishMenuLunch;

import java.math.BigDecimal;
import java.time.LocalDate;

public class OrderBuilder {

  private LocalDate date = LocalDate.now();
  private ItalianMenuLunch italianDish;
  private MexicanMenuLunch mexicanDish;
  private PolishMenuLunch polishDish;
  private Drink drink;
  private MenuDesert desert;
  private BigDecimal price;

  public static OrderBuilder builder() {
    return new OrderBuilder();
  }

  public OrderBuilder withDate(LocalDate date) {
    this.date = date;
    return this;
  }

  public OrderBuilder withItalianDish(ItalianMenuLunch italianDish) {
    this.italianDish = italianDish;
    return this;
  }

  public OrderBuilder withMexicanDish(MexicanMenuLunch mexicanDish) {
    this.mexicanDish = mexicanDish;
    return this;
  }

  public OrderBuilder withPolishDish(PolishMenuLunch polishDish) {
    this.polishDish = polishDish;
    return this;
  }

  public OrderBuilder withDrink(Drink drink) {
    this.drink = drink;
    return this;
  }


  public OrderBuilder withDesert(MenuDesert desert) {
    this.desert = desert;
    return this;
  }

  public OrderBuilder withPrice(BigDecimal price) {
    this.price = price;
    return this;
  }

  public Order build() {
    return new Order(date, italianDish, mexicanDish, polishDish, drink, desert, price);
  }

}
