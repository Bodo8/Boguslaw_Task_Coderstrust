package model.drinks;

import model.menu.MenuDrink;
import model.menu.MenuExtra;

import java.io.Serializable;
import java.math.BigDecimal;

public class Drink implements Serializable {

  private MenuDrink drink;
  private MenuExtra extraToDrink;
  private BigDecimal priceDrink;

  public Drink() {
  }

  /**
   * constructor needed for builder.
   *
   * @param drink menu drinks.
   * @param extraToDrink extra to drinks.
   * @param priceDrink price drinks.
   */
  public Drink(MenuDrink drink, MenuExtra extraToDrink, BigDecimal priceDrink) {
    this.drink = drink;
    this.extraToDrink = extraToDrink;
    this.priceDrink = priceDrink;
  }

  public MenuDrink getDrink() {
    return drink;
  }

  public void setDrink(MenuDrink drink) {
    this.drink = drink;
  }

  public MenuExtra getExtraToDrink() {
    return extraToDrink;
  }

  public void setExtraToDrink(MenuExtra extraToDrink) {
    this.extraToDrink = extraToDrink;
  }

  public BigDecimal getPriceDrink() {
    return priceDrink;
  }

  public void setPriceDrink(BigDecimal priceDrink) {
    this.priceDrink = priceDrink;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
      return false;
    }

    Drink drink1 = (Drink) obj;

    if (drink != drink1.drink) {
      return false;
    }
    if (extraToDrink != drink1.extraToDrink) {
      return false;
    }
    return priceDrink != null ? priceDrink.equals(drink1.priceDrink) : drink1.priceDrink == null;
  }

  @Override
  public int hashCode() {
    int result = drink != null ? drink.hashCode() : 0;
    result = 31 * result + (extraToDrink != null ? extraToDrink.hashCode() : 0);
    result = 31 * result + (priceDrink != null ? priceDrink.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "Drink{"
        + "drink=" + drink
        + ", extraToDrink=" + extraToDrink
        + ", priceDrink=" + priceDrink
        + '}';
  }
}
