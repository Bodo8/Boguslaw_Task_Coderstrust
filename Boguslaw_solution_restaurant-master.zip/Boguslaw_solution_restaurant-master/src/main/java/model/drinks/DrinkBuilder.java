package model.drinks;

import model.menu.MenuDrink;
import model.menu.MenuExtra;

import java.math.BigDecimal;

public class DrinkBuilder {

  private MenuDrink drink;
  private MenuExtra extraToDrink;
  private BigDecimal price;

  public static DrinkBuilder builder() {
    return new DrinkBuilder();
  }

  public DrinkBuilder withDrink(MenuDrink drink) {
    this.drink = drink;
    return this;
  }

  public DrinkBuilder withExtraToDrink(MenuExtra extraToDrink) {
    this.extraToDrink = extraToDrink;
    return this;
  }

  public DrinkBuilder withPrice(BigDecimal price) {
    this.price = price;
    return this;
  }

  public Drink build() {
    return new Drink(drink, extraToDrink, price);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
      return false;
    }

    DrinkBuilder that = (DrinkBuilder) obj;

    if (drink != that.drink) {
      return false;
    }
    if (extraToDrink != that.extraToDrink) {
      return false;
    }
    return price != null ? price.equals(that.price) : that.price == null;
  }

  @Override
  public int hashCode() {
    int result = drink != null ? drink.hashCode() : 0;
    result = 31 * result + (extraToDrink != null ? extraToDrink.hashCode() : 0);
    result = 31 * result + (price != null ? price.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "DrinkBuilder{"
        + "drink=" + drink
        + ", extraToDrink=" + extraToDrink
        + ", price=" + price
        + '}';
  }
}
