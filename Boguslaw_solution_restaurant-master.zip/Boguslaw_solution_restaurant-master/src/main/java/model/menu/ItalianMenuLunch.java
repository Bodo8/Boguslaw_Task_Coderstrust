package model.menu;

public enum ItalianMenuLunch {
  PIZZA,
  SPAGETTI,
  LASAGNE;
}
