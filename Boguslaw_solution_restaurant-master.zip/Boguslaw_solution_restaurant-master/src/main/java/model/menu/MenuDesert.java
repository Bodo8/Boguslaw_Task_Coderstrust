package model.menu;

public enum MenuDesert {
  CHOCOLATE_CAKE,
  ICE_CREAM,
  TIRAMISU;
}
