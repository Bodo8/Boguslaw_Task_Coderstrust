package model.menu;

public enum MenuDrink {
  WATER,
  WHISKY,
  PEPSI;
}
