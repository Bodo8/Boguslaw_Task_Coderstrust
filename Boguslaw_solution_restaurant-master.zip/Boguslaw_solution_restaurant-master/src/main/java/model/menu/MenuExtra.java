package model.menu;

public enum MenuExtra {
  ICE_CUBES,
  LEMON;
}
