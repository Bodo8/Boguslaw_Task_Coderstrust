package model.menu;

public enum MexicanMenuLunch {
  BURRITO,
  NACHOS;
}
