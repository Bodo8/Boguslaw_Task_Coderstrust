package model.menu;

public enum PolishMenuLunch {
  FISH,
  CHICKEN,
  CHICKEN_SOUP;
}

