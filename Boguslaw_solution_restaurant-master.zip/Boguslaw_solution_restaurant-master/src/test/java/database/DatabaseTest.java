package database;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import generatorfortests.GenerateOrder;
import model.Order;
import org.junit.Test;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public abstract class DatabaseTest {

  protected abstract Database provideDatabase();

  @Test
  public void shouldSaveOrder() throws Exception {
    //given
    Database database = provideDatabase();
    Order order = GenerateOrder.generateOrderForTest();
    //when
    database.saveOrder(order);
    //then
    List<Order> actual = database.getAllOrders();
    assertNotNull(actual);
    assertEquals(order, actual.get(0));
  }

  @Test
  public void shouldRemoveOrderFromDatabase() throws IOException {
    //given

    Database database = provideDatabase();

    List<Order> expectedOrders = GenerateOrder
        .generateListOfOrders(100)
        .stream()
        .sorted()
        .collect(Collectors.toList());
    expectedOrders.stream().forEach(database::saveOrder);

    // when
    Order order;
    int sizeOfList = expectedOrders.size();
    for (int i = 0; i < sizeOfList; i++) {
      order = database.getAllOrders().get(i);
      database.removeOrder(order);
      sizeOfList--;
      //then
      assertEquals(database.getAllOrders().size(), sizeOfList);
    }
  }

  @Test
  public void shouldReadOrderWhichWasSavedInDatabase() throws IOException {
    //given

    Database database = provideDatabase();
    Order order = GenerateOrder
        .generateOrderForTest();
    //when
    database.saveOrder(order);
    //then
    final List<Order> listOfOrders = database.getAllOrders();
    assertNotNull("List of orders should not be null.", listOfOrders);
    assertEquals(1, listOfOrders.size());
    assertEquals(order, listOfOrders.get(0));
  }

}