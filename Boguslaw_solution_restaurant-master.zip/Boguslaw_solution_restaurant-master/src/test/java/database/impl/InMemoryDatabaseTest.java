package database.impl;

import database.Database;
import database.DatabaseTest;

public class InMemoryDatabaseTest extends DatabaseTest {

  @Override
  protected Database provideDatabase() {
    return new InMemoryDatabase();
  }
}