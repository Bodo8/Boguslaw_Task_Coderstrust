package generatorfortests;

import model.Order;
import model.OrderBuilder;
import model.drinks.DrinkBuilder;
import model.menu.ItalianMenuLunch;
import model.menu.MenuDesert;
import model.menu.MenuDrink;
import model.menu.MenuExtra;
import model.menu.MexicanMenuLunch;
import model.menu.PolishMenuLunch;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class GenerateOrder {

  public GenerateOrder() {
  }

  /**
   * Generate order for the tests.
   *
   * @return object order class.
   */
  public static Order generateOrderForTest() {

    Order order = OrderBuilder.builder()
        .withDate(LocalDate.now())
        .withDrink(DrinkBuilder.builder()
            .withDrink(MenuDrink.WHISKY)
            .withExtraToDrink(MenuExtra.ICE_CUBES)
            .withPrice(BigDecimal.TEN)
            .build())
        .withItalianDish(ItalianMenuLunch.LASAGNE)
        .withMexicanDish(MexicanMenuLunch.BURRITO)
        .withPolishDish(PolishMenuLunch.CHICKEN_SOUP)
        .withDesert(MenuDesert.CHOCOLATE_CAKE)
        .withPrice(BigDecimal.TEN)
        .build();
    return order;
  }

  /**
   * Generate list object order for the test.
   * @param numberOfOrders indicates the number of objects.
   * @return list object order class.
   */
  public static List<Order> generateListOfOrders(int numberOfOrders) {
    List<Order> orderList = new ArrayList<>();
    for (int i = 0; i < numberOfOrders; i++) {
      Order order = OrderBuilder.builder()
          .withDate(LocalDate.now())
          .withDrink(DrinkBuilder.builder()
              .withDrink(MenuDrink.WHISKY)
              .withExtraToDrink(MenuExtra.ICE_CUBES)
              .withPrice(BigDecimal.TEN)
              .build())
          .withItalianDish(ItalianMenuLunch.LASAGNE)
          .withMexicanDish(MexicanMenuLunch.BURRITO)
          .withPolishDish(PolishMenuLunch.CHICKEN_SOUP)
          .withDesert(MenuDesert.CHOCOLATE_CAKE)
          .withPrice(BigDecimal.TEN)
          .build();
    }
    return orderList;
  }

}
