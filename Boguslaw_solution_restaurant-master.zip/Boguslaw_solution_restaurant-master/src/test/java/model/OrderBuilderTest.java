package model;

import static generatorfortests.GenerateOrder.generateOrderForTest;
import static org.junit.Assert.assertEquals;

import model.drinks.DrinkBuilder;
import model.menu.ItalianMenuLunch;
import model.menu.MenuDesert;
import model.menu.MenuDrink;
import model.menu.MenuExtra;
import model.menu.MexicanMenuLunch;
import model.menu.PolishMenuLunch;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

public class OrderBuilderTest {

  @Test
  public void shouldCreateOrder() throws Exception {
    //given
    Order expectedOrder = OrderBuilder.builder()
        .withDate(LocalDate.now())
        .withDrink(DrinkBuilder.builder()
            .withDrink(MenuDrink.WHISKY)
            .withExtraToDrink(MenuExtra.ICE_CUBES)
            .withPrice(BigDecimal.TEN)
            .build())
        .withItalianDish(ItalianMenuLunch.LASAGNE)
        .withMexicanDish(MexicanMenuLunch.BURRITO)
        .withPolishDish(PolishMenuLunch.CHICKEN_SOUP)
        .withDesert(MenuDesert.CHOCOLATE_CAKE)
        .withPrice(BigDecimal.TEN)
        .build();
    //when
    Order actualOrder = generateOrderForTest();
    //then
    assertEquals(expectedOrder, actualOrder);
  }

}